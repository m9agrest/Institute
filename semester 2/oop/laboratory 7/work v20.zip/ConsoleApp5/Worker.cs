﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Worker
    {
        protected string name;
        protected string boss;
        List<string> slaves = new List<string>();
            
        public Worker(string name, string boss)
        {
            this.name = name;
            this.boss = boss;
        } 

        public void AddSlave(string name)
        {
            slaves.Add(name);
        }

        public virtual void PrintSlaves()
        {
            Console.WriteLine("Подчиненные:");
            foreach (string slave in slaves)
            {
                Console.WriteLine(slave);
            }
        }

        public virtual void PrintTasks()
        {
            Console.WriteLine($"Обязанности работника {name}");
            Console.WriteLine("Придти в 8 утра");
            Console.WriteLine("Попить кофе");
            Console.WriteLine("Поболтать");
            Console.WriteLine("Поспать");
            Console.WriteLine("Уйти с работы");
        }
    }
}
