﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker[] stado = new Worker[5];

            stado[0] = new Manager("Иван");
            stado[1] = new Developer("Семен", "Иван");
            stado[2] = new Coder("Алеша", "Семен");
            stado[3] = new Coder("Анатолий", "Семен");
            stado[4] = new Coder("Альберт", "Семен");

            foreach(Worker worker in stado)
            {
                worker.PrintTasks();
            }
            Console.ReadKey();
        }
    }
}
