﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Developer : Worker
    {
        public Developer(string name, string boss) : base(name, boss)
        {

        }

        public override void PrintTasks()
        {
            Console.WriteLine($"Обязанности разработчика {name}");
            Console.WriteLine("Придти на работу");
            Console.WriteLine("Собрать младших программистов");
            Console.WriteLine("Поругать их");
        }
    }
}
