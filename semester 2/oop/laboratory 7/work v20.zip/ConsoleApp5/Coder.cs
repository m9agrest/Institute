﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Coder : Developer
    {
        public Coder(string name, string boss) : base(name, boss)
        {

        }

        public override void PrintTasks()
        {
            Console.WriteLine($"Обязаности младшего программиста {name}");
            Console.WriteLine("Придти на работу");
            Console.WriteLine("Обсудить спленти о начальнике");
            Console.WriteLine("Получить нагоняй");
        }
    }
}
