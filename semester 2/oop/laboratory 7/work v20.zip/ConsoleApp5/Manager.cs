﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Manager : Worker
    {
        public Manager(string name) : base(name,"")
        {

        }

        public override void PrintTasks()
        {
            Console.WriteLine($"Обязанности менеджера {name}");
            Console.WriteLine("Ругать подчиненных");
            Console.WriteLine("Ругать подчиненных");
            Console.WriteLine("Ругать подчиненных");
            Console.WriteLine("Ругать подчиненных");
            Console.WriteLine("Ругать подчиненных");

        }
    }
}
