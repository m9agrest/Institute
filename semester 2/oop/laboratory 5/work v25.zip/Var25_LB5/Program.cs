﻿using System;

namespace Var25_LB5
{
    class MyArray
    {
        public int[] array;

        public MyArray(int count, int min, int max)
        {
            array = new int[count];

            Random rnd = new Random();
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rnd.Next(min, max);
            }
        }

        public MyArray(string arr)
        {
            string[] items = arr.Split(',');

            array = new int[items.Length];

            for (int i = 0; i < items.Length; i++)
            {
                array[i] = int.Parse(items[i]);
            }
        }

        public int ArrayLenght
        {
            get
            {
                return array.Length;
            }
        }


        public int AbsSumItem()
        {
            int s = 0;
            int i = 0;
            for (i = 0; i < array.Length; i++)
            {
                if (array[i] < 0)
                    break;
            }

            for (int j = i+1; j < array.Length; j++)
            {
                s += Math.Abs(array[j]);
            }

            return s;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyArray array = new MyArray(10, -10, 100);
            MyArray array1 = new MyArray("10,51,-68,0,4");

            Console.WriteLine("Размер первого массива {0}", array.ArrayLenght);
            Console.WriteLine("Сумма модулей первого массива {0}",array.AbsSumItem());

            Console.WriteLine("Размер первого массива {0}", array1.ArrayLenght);
            Console.WriteLine("Сумма модулей первого массива {0}", array1.AbsSumItem());

        }
    }
}
