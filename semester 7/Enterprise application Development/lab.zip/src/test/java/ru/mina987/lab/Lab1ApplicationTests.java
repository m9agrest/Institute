package ru.mina987.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class labApplicationTests {

	@Test
	void contextLoads() {
	}

}
