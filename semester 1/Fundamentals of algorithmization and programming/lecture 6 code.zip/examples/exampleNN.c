#include <stdio.h>
 int main() {
    int a = 1;
    int b = 2;
    int c = 3;
    //int mid;

    //mid = (a > b) ? ((a > c) ? ((c > b) ? c : b) : a) : ((b > c) ? ((c > a) ? c : a) : b);
 
    c = a+++ b++;

    printf("%d", c);
    printf("%d", a);
    
    getchar();
    getchar();
    return 0;
}
