#include <stdio.h>
int main() 
{
    int a, b, c;
    c = (a = 3, b = 4);
    printf("%d", c);
    getchar();
    return 0;
}