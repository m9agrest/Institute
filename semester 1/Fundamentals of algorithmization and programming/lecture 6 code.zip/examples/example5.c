#include <stdio.h>
int main()
{
   int a = 1;
   int b = 2;
   int c = 3;
   int mid;

   mid = (a>b)?((a>c)?((c>b)?c:b):a):((b>c)?((c>a)?c:a):b);

   printf("%d", mid);
   getchar();
   getchar();
   return 0;
}