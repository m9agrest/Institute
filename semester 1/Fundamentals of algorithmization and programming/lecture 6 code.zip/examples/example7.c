#include <stdio.h>
int foo(int a) 
{
    return a % 5 + a*a;
}
int main() 
{
    int i = 0, mod;
    while (mod = foo(i), mod < 100) 
    {
        printf("%d ", i++);
    }
    getchar();
    return 0;
}