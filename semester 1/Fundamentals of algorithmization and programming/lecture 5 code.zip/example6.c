#include <stdio.h>
#define N 10
int main() 
{
    int a[N] = {1, 2, 5, 3, 9, 1, 7, 7, 2, 4};
    int max = 0;
    for (unsigned i = 1; i < N; i++) 
    {
        if (a[i] <= a[max]) 
        {
            max = i;
        }
    }
    printf("Min element is a[%d]=%d", max, a[max]);
    getchar();
    return 0;
}
