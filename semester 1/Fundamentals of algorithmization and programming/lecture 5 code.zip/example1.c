#include <stdio.h>
int main() 
{
    int a[100];
    a[0] = 10;
    a[10] = 333;
    a[12] = 234;
    printf("%d %d %d %d", a[0], a[10], a[12], a[99]);
    getchar();
 }
