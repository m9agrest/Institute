#include<stdio.h>
int main() 
{
    double points[] = {1.0, 3.14, -1.2, 12.65, 56, 76, 87.9};
    int k;
    int npoints = sizeof(points) / sizeof(points[0]);

    for(k = 0; k < npoints; k++) 
    {
        printf("points[%d] = %.2lf\n", k, points[k]);
    }
    return 0;
} 
