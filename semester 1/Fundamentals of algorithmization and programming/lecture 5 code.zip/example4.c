#include <stdio.h>
#define NPOINTS 100
int main() {
    double points[NPOINTS];
    int k;
    points[0] = 0.1;
    for(k = 1; k < NPOINTS; k++) 
    {
        points[k] = 0.1 + points[k-1];
    }
    for(k = 1; k < NPOINTS; k++) 
    {
        printf("%.1lf ", points[k]);
    }
    return 0;
}