﻿using System;

namespace lab6
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
